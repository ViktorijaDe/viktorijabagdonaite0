const apiKey = "pk.eyJ1IjoidmlrdG9yaWphZGUiLCJhIjoiY2t6ZDZrM2p1MjZqaDJ2bng4Y2tkMWV2aSJ9.X0YuJyocvrUmxgnVe3LmNA";

const myMap = L.map('map').setView([51.505, -0.09], 2);




L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: apiKey
}).addTo(myMap);

L.control.locate().addTo(myMap);




//current Location in Console
/*function onMapClick(e) {
    if ("geolocation" in navigator){ 
        navigator.geolocation.getCurrentPosition(function(position){ 
                console.log("Your location is \nLat : "+position.coords.latitude+" \nLang :"+ position.coords.longitude);
            });
    }else{
        console.log("Browser doesn't support geolocation!");
    }
}*/
//Populate nav meniu
$.ajax({
    url: './php/getBorders.php',
    type: 'POST',
    dataType: "json",
    
    success: function(result) {
        //console.log(result);
        
        for (var i=0; i<result.data.border.features.length; i++) {
            $('#selCountry').append($('<option>', {
                value: result.data.border.features[i].properties.iso_a3,
                text: result.data.border.features[i].properties.name,
            }));
           }
        }
    });
//On Cick zoom country borders
let border;

$('#selCountry').click(function() {
    let name = $('#selCountry').val();
    $.ajax({
        url: './php/getBorders.php',
        type: 'POST',
        dataType: 'json',
        success: function(result) {
            if (myMap.hasLayer(border)) {
                myMap.removeLayer(border);
            }
            const filterData = result.data.border.features.filter((a) => (a.properties.iso_a3 === name));
            border = L.geoJSON(filterData[0]); 
            myMap.fitBounds(border.getBounds());
        }
    })
})

const iconImg = document.getElementById('weather-icon');
const loc = document.querySelector('#location');
const tempC = document.querySelector('.c');
const tempF = document.querySelector('.f');
const desc = document.querySelector('.desc');
const sunriseDOM = document.querySelector('.sunrise');
const sunsetDOM = document.querySelector('.sunset');

window.addEventListener('load', () => {
    let long;
    let lat;
    // Accessing Geolocation of User
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        long = position.coords.longitude;
        lat = position.coords.latitude;

        function base(){
            const url = './php/openweather.php';
                fetch(result)
                 .then((response) => {
                     return response.json();
                 })
                 .then((data) => {
                     const { temp } = data.main;
                     const place = data.name;
                     const { description, icon } = data.weather[0];
                     const { sunrise, sunset } = data.sys;

                     const iconUrl = `http://openweathermap.org/img/wn/${icon}@2x.png`;
                     const fahrenheit = (temp * 9) / 5 + 32; 

                    const sunriseGMT = new Date(sunrise * 1000);
                    const sunsetGMT = new Date(sunset * 1000);

                    iconImg.src = iconUrl;
                    loc.textContent = `${place}`;
                    desc.textContent = `${description}`;
                    tempC.textContent = `${temp.toFixed(2)} °C`;
                    tempF.textContent = `${fahrenheit.toFixed(2)} °F`;
                    sunriseDOM.textContent = `${sunriseGMT.toLocaleDateString()}, ${sunriseGMT.toLocaleTimeString()}`;
                    sunsetDOM.textContent = `${sunsetGMT.toLocaleDateString()}, ${sunsetGMT.toLocaleTimeString()}`;
                 })

                 
            
        }
       
      });
    }
  });